*PADS-LIBRARY-PART-TYPES-V9*

ADS1015BQDGSRQ1 SOP50P490X110-10N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.18.02.06.16
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" ADS1015BQDGSRQ1
"Mouser Part Number" 595-ADS1015BQDGSRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/ADS1015BQDGSRQ1?qs=34RfhUjJmKfZv563%2FD593g%3D%3D
"Arrow Part Number" ADS1015BQDGSRQ1
"Arrow Price/Stock" https://www.arrow.com/en/products/ads1015bqdgsrq1/texas-instruments.html?utm_currency=USD&region=nac
"Description" Automotive 12-Bit 3.3kSPS 4-Ch Delta-Sigma ADC With PGA, Oscillator, VREF, Comparator, and I2C
"Datasheet Link" http://www.ti.com/lit/gpn/ads1015-q1
"Geometry.Height" 1.1mm
GATE 1 10 0
ADS1015BQDGSRQ1
1 0 U ADDR
2 0 U ALERT/RDY
3 0 U GND
4 0 U AIN0
5 0 U AIN1
10 0 U SCL
9 0 U SDA
8 0 U VDD
7 0 U AIN3
6 0 U AIN2

*END*
*REMARK* SamacSys ECAD Model
642676/2218365/2.50/10/4/Integrated Circuit
